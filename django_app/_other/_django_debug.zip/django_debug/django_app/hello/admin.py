from django.contrib import admin
from .models import Friend,Message

admin.site.register(Friend)
admin.site.register(Message)
